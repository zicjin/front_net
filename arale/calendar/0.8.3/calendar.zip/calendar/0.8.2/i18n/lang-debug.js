define("arale/calendar/0.8.2/i18n/lang-debug", [], {});
